package com.airplanecompany.admin.dao;

import com.airplanecompany.admin.entity.Details;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DetailsDao extends JpaRepository<Details, String> {

    @Query(value = "select d from Details as d where d.price=:price")
    List<Details> findDetailsByPrice(@Param("price") int price);

    @Query(value = "select d from Details as d where d.flight.toLocation=:location")
    List<Details> findDetailsByFlight(@Param("location") String location);
}
