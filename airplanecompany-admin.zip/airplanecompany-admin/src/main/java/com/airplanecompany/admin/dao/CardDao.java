package com.airplanecompany.admin.dao;

import com.airplanecompany.admin.entity.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CardDao extends JpaRepository<Card, Long> {

    @Query(value = "select c from Card as c where c.cardNumber like %:number%")
    List<Card> findCardByCardNumber(@Param("number") String number);
}
