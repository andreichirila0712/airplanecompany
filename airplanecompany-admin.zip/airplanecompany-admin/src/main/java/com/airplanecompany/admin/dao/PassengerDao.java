package com.airplanecompany.admin.dao;

import com.airplanecompany.admin.entity.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PassengerDao extends JpaRepository<Passenger, Long> {

    @Query(value = "select * from flights as f where f.flight_id in (select e.flight_id from tickets as e where f.flight_id=:flightID)", nativeQuery = true)
    List<Passenger> getPassengerByFlightId(@Param("flightID") Long flightID);

    @Query(value = "select p from Passenger as p where p.firstName like %:name% or p.lastName like %:name%")
    List<Passenger> findPassengersByName(String name);

    @Query(value = "select p from Passenger  as p where p.user.email=:email")
    Passenger findPassengersByEmail(@Param("email") String email);

}
