package com.airplanecompany.admin.entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "cards")
public class Card {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "card_id", nullable = false)
    private Long cardID;
    @Basic
    @Column(name = "card_number", nullable = false, length = 45, unique = true)
    private String cardNumber;
    @Basic
    @Column(name = "card_type", nullable = false, length = 45)
    private String cardType;
    @Basic
    @Column(name = "expiration_month", nullable = false)
    private int expirationMonth;
    @Basic
    @Column(name = "expiration_year", nullable = false)
    private int expirationYear;

    @ManyToOne
    @JoinColumn(name = "passenger_id", nullable = false)
    private Passenger passenger;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Card card = (Card) o;
        return expirationMonth == card.expirationMonth && expirationYear == card.expirationYear && cardID.equals(card.cardID) && Objects.equals(cardNumber, card.cardNumber) && Objects.equals(cardType, card.cardType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cardID, cardNumber, cardType, expirationMonth, expirationYear);
    }

    public Long getCardID() {
        return cardID;
    }

    public void setCardID(Long cardID) {
        this.cardID = cardID;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public int getExpirationMonth() {
        return expirationMonth;
    }

    public void setExpirationMonth(int expirationMonth) {
        this.expirationMonth = expirationMonth;
    }

    public int getExpirationYear() {
        return expirationYear;
    }

    public void setExpirationYear(int expirationYear) {
        this.expirationYear = expirationYear;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public Card() {
    }

    public Card(String cardNumber, String cardType, int expirationMonth, int expirationYear, Passenger passenger) {
        this.cardNumber = cardNumber;
        this.cardType = cardType;
        this.expirationMonth = expirationMonth;
        this.expirationYear = expirationYear;
        this.passenger = passenger;
    }

    @Override
    public String toString() {
        return "Card{" +
                "cardID=" + cardID +
                ", cardNumber='" + cardNumber + '\'' +
                ", cardType='" + cardType + '\'' +
                ", expirationMonth=" + expirationMonth +
                ", expirationYear=" + expirationYear +
                '}';
    }
}
