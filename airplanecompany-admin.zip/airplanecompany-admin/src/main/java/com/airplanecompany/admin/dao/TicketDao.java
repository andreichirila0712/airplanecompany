package com.airplanecompany.admin.dao;

import com.airplanecompany.admin.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TicketDao extends JpaRepository<Ticket, Long> {

    @Query(value = "select t from Ticket as t where t.status like %:status%")
    List<Ticket> findTicketByStatus(@Param("status") String status);
}
