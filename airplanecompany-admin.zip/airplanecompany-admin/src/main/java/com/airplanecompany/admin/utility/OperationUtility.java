package com.airplanecompany.admin.utility;

import com.airplanecompany.admin.dao.*;
import com.airplanecompany.admin.entity.*;
import jakarta.persistence.EntityNotFoundException;

import java.util.List;
import java.util.Optional;

public class OperationUtility {
    public static void usersOperations(UserDao userDao) {
        createUsers(userDao);
        updateUser(userDao);
        deleteUser(userDao);
        fetchUsers(userDao);
    }

    public static void rolesOperations(RoleDao roleDao) {
        createRoles(roleDao);
        updateRole(roleDao);
        deleteRole(roleDao);
        fetchRole(roleDao);
    }


    private static void createUsers(UserDao userDao) {
        User user1 = new User("user1@gmail.com", "pass1");
        userDao.save(user1);
        User user2 = new User("user2@gmail.com", "pass2");
        userDao.save(user2);
        User user3 = new User("user3@gmail.com", "pass3");
        userDao.save(user3);
        User user4 = new User("user4@gmail.com", "pass4");
        userDao.save(user4);
    }

    private static void updateUser(UserDao userDao) {
        User user = userDao.findById(2L).orElseThrow(() -> new EntityNotFoundException("User Not Found"));
        user.setEmail("newEmail@gmail.com");
        userDao.save(user);
    }

    private static void deleteUser(UserDao userDao) {
        User user = userDao.findById(3L).orElseThrow(() -> new EntityNotFoundException("User Not Found"));
        userDao.delete(user);
    }

    private static void fetchUsers(UserDao userDao) {
        userDao.findAll().forEach(user -> System.out.println(user.toString()));
    }

    private static void createRoles(RoleDao roleDao) {
        Role role1 = new Role("Admin");
        roleDao.save(role1);
        Role role2 = new Role("Passenger");
        roleDao.save(role2);
    }

    private static void updateRole(RoleDao roleDao) {
        Role role = roleDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Role Not Found"));
        role.setName("NewAdmin");
        roleDao.save(role);
    }

    private static void deleteRole(RoleDao roleDao) {
        roleDao.deleteById(2L);
    }

    private static void fetchRole(RoleDao roleDao) {
        roleDao.findAll().forEach(role -> System.out.println(role.toString()));
    }

    public static void assignRolesToUsers(UserDao userDao, RoleDao roleDao) {
        Role role = roleDao.findByName("Admin");
        if (role == null) throw new EntityNotFoundException("Role Not Found");
        List<User> users = userDao.findAll();
        users.forEach(user -> {
            user.assignRoleToUser(role);
            userDao.save(user);
        });
    }

    public static void passengersOperations(UserDao userDao, PassengerDao passengerDao, RoleDao roleDao,
                                            FlightDao flightDao) {
        createPassengers(userDao, passengerDao, roleDao);
        updatePassenger(passengerDao);
        removePassenger(passengerDao);
        fetchPassengers(passengerDao);
        assignFlightToPassenger(flightDao, passengerDao);
        fetchFlightsForPassenger(flightDao);
    }

    private static void fetchFlightsForPassenger(FlightDao flightDao) {
        flightDao.getFlightsByPassengersAndFlightID(1L).forEach(flight -> System.out.println(flight.toString()));

    }

    private static void createPassengers(UserDao userDao, PassengerDao passengerDao, RoleDao roleDao) {
        Role role = roleDao.findByName("Passenger");
        if (role == null) throw new EntityNotFoundException("Role Not Found");

        User user1 = new User("passenger1@gmail.com", "pass1");
        userDao.save(user1);
        user1.assignRoleToUser(role);

        Passenger passenger1 = new Passenger("passenger1FN", "passenger1LN", "passenger1PN",
                "passenger1E@gmail.com", user1);
        passengerDao.save(passenger1);

        User user2 = new User("passenger2@gmail.com", "pass2");
        userDao.save(user2);
        user2.assignRoleToUser(role);

        Passenger passenger2 = new Passenger("passenger2FN", "passenger2LN", "passenger2PN",
                "passenger2E@gmail.com", user2);
        passengerDao.save(passenger2);
    }

    private static void updatePassenger(PassengerDao passengerDao) {
        Passenger passenger = passengerDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Passenger Not Found"));
        passenger.setPhoneNumber("0752179113");
        passengerDao.save(passenger);
    }

    private static void removePassenger(PassengerDao passengerDao) {
        passengerDao.deleteById(2L);
    }

    private static void fetchPassengers(PassengerDao passengerDao) {
        passengerDao.findAll().forEach(passenger -> System.out.println(passenger.toString()));
    }

    private static void assignFlightToPassenger(FlightDao flightDao, PassengerDao passengerDao) {
        Optional<Flight> flight1 = flightDao.findById(1L);
        Optional<Flight> flight2 = flightDao.findById(2L);
        Passenger passenger = passengerDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Passenger Not Found"));

        flight1.ifPresent(passenger::assignFlightToPassenger);
        flight2.ifPresent(passenger::assignFlightToPassenger);
        passengerDao.save(passenger);
    }


    public static void cardsOperations(UserDao userDao, PassengerDao passengerDao, CardDao cardDao, RoleDao roleDao) {
        createCards(userDao, passengerDao, cardDao, roleDao);
        updateCard(cardDao);
        removeCard(cardDao);
        fetchCards(cardDao);
    }

    private static void createCards(UserDao userDao, PassengerDao passengerDao, CardDao cardDao, RoleDao roleDao) {
        Role role = roleDao.findByName("Passenger");
        if (role == null) throw new EntityNotFoundException("Role Not Found");

        User user1 = new User("passengerUser1@gmail.com", "pass1");
        userDao.save(user1);
        user1.assignRoleToUser(role);

        Passenger passenger = new Passenger("passengerFN", "passengerLN", "passengerPN",
                "passengerE@gmail.com", user1);
        passengerDao.save(passenger);

        Card card = new Card("cN1", "cT1", 1, 1, passenger);
        cardDao.save(card);
    }

    private static void updateCard(CardDao cardDao) {
        Card card = cardDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Card Not Found"));
        card.setCardNumber("updateCN");
        card.setCardType("updateCT");
        cardDao.save(card);
    }

    private static void removeCard(CardDao cardDao) {
        cardDao.deleteById(1L);
    }

    private static void fetchCards(CardDao cardDao) {
        cardDao.findAll().forEach(card -> System.out.println(card.toString()));
    }

    public static void detailsOperations(DetailsDao detailsDao) {
        createDetails(detailsDao);
        updateDetail(detailsDao);
        removeDetail(detailsDao);
        fetchDetails(detailsDao);
    }

    private static void createDetails(DetailsDao detailsDao) {
        Details details1 = new Details(100, 250);
        detailsDao.save(details1);

        Details details2 = new Details(150, 300);
        detailsDao.save(details2);
    }

    private static void updateDetail(DetailsDao detailsDao) {
        Details details = detailsDao.findById("1").orElseThrow(() -> new EntityNotFoundException("Details Not Found"));
        details.setPrice(230);
        detailsDao.save(details);
    }

    private static void removeDetail(DetailsDao detailsDao) {
        detailsDao.deleteById("1");
    }

    private static void fetchDetails(DetailsDao detailsDao) {
        detailsDao.findAll().forEach(details -> System.out.println(details.toString()));
    }

    public static void flightsOperations(FlightDao flightDao, DetailsDao detailsDao) {
        createFlights(flightDao, detailsDao);
        updateFlight(flightDao);
        removeFlight(flightDao);
        fetchFlights(flightDao);

    }


    private static void createFlights(FlightDao flightDao, DetailsDao detailsDao) {
        Details details = detailsDao.findById("1").orElseThrow(() -> new EntityNotFoundException("Details Not Found"));
        Flight flight = new Flight("Wizz", "Bucuresti", "Bologna", "14:10",
                "16:10", "2h", 250, details);
        flightDao.save(flight);
    }

    private static void updateFlight(FlightDao flightDao) {
        Flight flight = flightDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Flight Not Found"));
        flight.setAirlineName("TAROM");
        flightDao.save(flight);
    }

    private static void removeFlight(FlightDao flightDao) {
        flightDao.deleteById(1L);
    }

    private static void fetchFlights(FlightDao flightDao) {
        flightDao.findAll().forEach(flight -> System.out.println(flight.toString()));
    }

    public static void ticketsOperations(TicketDao ticketDao, DetailsDao detailsDao,
                                         FlightDao flightDao, PassengerDao passengerDao) {
        createTickets(ticketDao, detailsDao, flightDao, passengerDao);
        updateTicket(ticketDao);
        removeTicket(ticketDao);
        fetchTickets(ticketDao);
    }

    private static void createTickets(TicketDao ticketDao, DetailsDao detailsDao, FlightDao flightDao,
                                      PassengerDao passengerDao) {
        Passenger passenger = passengerDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Passenger Not Found"));
        Details detail = detailsDao.findById("1").orElseThrow(() -> new EntityNotFoundException("Detail Not Found"));
        Flight flight = flightDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Flight Not Found"));

        Ticket ticket = new Ticket("cumparat", passenger, detail, flight);
        ticketDao.save(ticket);
    }

    private static void updateTicket(TicketDao ticketDao) {
        Ticket ticket = ticketDao.findById(1L).orElseThrow(() -> new EntityNotFoundException("Ticket Not Found"));
        ticket.setStatus("necumparat");
        ticketDao.save(ticket);
    }

    private static void removeTicket(TicketDao ticketDao) {
        ticketDao.deleteById(1L);
    }

    private static void fetchTickets(TicketDao ticketDao) {
        ticketDao.findAll().forEach((ticket -> System.out.println(ticket.toString())));
    }


}

