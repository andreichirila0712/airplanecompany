package com.airplanecompany.admin.entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "details")
public class Details {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "flight_date", nullable = false, length = 45)
    private String flightDate;
    @Basic
    @Column(name = "price", nullable = false)
    private int price;
    @Basic
    @Column(name = "available_seats", nullable = false)
    private int availableSeats;

    @OneToOne(mappedBy = "flightDate")
    private Flight flight;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Details details = (Details) o;
        return price == details.price && availableSeats == details.availableSeats && flightDate.equals(details.flightDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(flightDate, price, availableSeats);
    }

    public String getFlightDate() {
        return flightDate;
    }

    public void setFlightDate(String flightDate) {
        this.flightDate = flightDate;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Details() {
    }

    public Details(int price, int availableSeats) {
        this.price = price;
        this.availableSeats = availableSeats;
    }

    @Override
    public String toString() {
        return "Details{" +
                "flightDate='" + flightDate + '\'' +
                ", price=" + price +
                ", availableSeats=" + availableSeats +
                '}';
    }
}
