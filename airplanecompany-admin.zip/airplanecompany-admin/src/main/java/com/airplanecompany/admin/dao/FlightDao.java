package com.airplanecompany.admin.dao;

import com.airplanecompany.admin.entity.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FlightDao extends JpaRepository<Flight, Long> {

    @Query(value = "select f from Flight as f where f.airlineName like %:name%")
    List<Flight> findFlightByAirlineName(@Param("name") String name);

    @Query(value = "select f from Flight as f where f.fromLocation like %:location%")
    List<Flight> findFlightByFromLocation(@Param("location") String location);

    @Query(value = "select * from passengers as p where p.passenger_id in (select e.passenger_id from tickets as e where p.passenger_id=:passengerID)", nativeQuery = true)

    List<Flight> getFlightsByPassengersAndFlightID(@Param("passengerID") Long passengerID);
}
